package com.knst.calendar.di.modules;

import dagger.Module;

@Module
public abstract class MainChildFragmentModule {
}
