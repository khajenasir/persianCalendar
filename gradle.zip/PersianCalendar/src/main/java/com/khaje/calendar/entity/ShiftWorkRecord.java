package com.knst.calendar.entity;

public class ShiftWorkRecord {
    final public String type;
    final public int length;

    public ShiftWorkRecord(String type, int length) {
        this.type = type;
        this.length = length;
    }
}
