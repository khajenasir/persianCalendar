package com.knst.calendar.util;

// So vital, don't ever change names of these
public enum CalendarType {
    SHAMSI, ISLAMIC, GREGORIAN
}
