//package com.knst.calendar.di.dependencies;
//
//import com.knst.calendar.di.scopes.PerChildFragment;
//
//import javax.inject.Inject;
//
//@PerChildFragment
//public final class MonthFragmentDependency {
//    @Inject
//    public MonthFragmentDependency() {
//    }
//}
