package com.khaje.calendar;

import android.app.Application;

public class ReleaseDebugDifference {
    public static void mainApplication(Application app) {
        // Nothing
    }
}
